#!/bin/python3

import sys
import os
import shutil

def main():
    if len(sys.argv) != 3:
        print("Incorrect arg count.")
        print("Usage: ./exe <fuzzout_dir> <output_dir>")
        return

    fuzzout_dir = sys.argv[1]
    output_dir = sys.argv[2]

    if not os.path.isdir(fuzzout_dir):
        print(f'Directory "{fuzzout_dir}" does not exist')
        return

    os.makedirs(output_dir, exist_ok=True)
    full_output_dir = os.path.join(output_dir, 'full')
    os.makedirs(full_output_dir, exist_ok=True)
    reverse_output_dir = os.path.join(output_dir, 'reverse')
    os.makedirs(reverse_output_dir, exist_ok=True)
    sorted_dir = os.path.join(output_dir, 'sorted')
    os.makedirs(sorted_dir, exist_ok=True)

    outputs = {}

    for entry in os.scandir(fuzzout_dir):
        if not entry.is_file():
            continue
        
        source_file, mode, executable = entry.name.split('.')
        raw_path = entry.path
        with open(entry.path, 'r') as crash_report:
            contents = crash_report.read().strip()
            if contents == "":
                continue
            
            if not source_file in outputs:
                outputs[source_file] = []

            content_desc = (mode, executable, contents, raw_path)
            
            outputs[source_file] += [content_desc]
            
    for file_name, content_list in outputs.items():
        out_file_name = os.path.join(full_output_dir, f'{file_name}.summary')
        with open(out_file_name, 'w') as output_file:
            for content_desc in content_list:
                mode, executable, contents, _ = content_desc[:]
                output_file.write(f'==========> {mode}.{executable}: {contents}\n')

    # associate error message with source input file
    reverse_outputs = {}
    for file_name, content_list in outputs.items():
        for content_desc in content_list:
            mode, executable, contents, raw_path = content_desc[:]
            content_lines = contents.splitlines()
            summary_line = next((line for line in content_lines if line.startswith("SUMMARY")), None)
            if summary_line:
                contents = summary_line

            if not contents in reverse_outputs:
                reverse_outputs[contents] = []
            
            file_desc = (file_name, mode, executable, raw_path)
            reverse_outputs[contents] += [file_desc]
    
    print(f'Counted {len(reverse_outputs)} unique error messages...')
    print('Only storing errors containing "SUMMARY" in sorted directory...')

    err_list_fname = os.path.join(output_dir, 'error_list.txt')
    with open(err_list_fname, 'w') as err_list_file:
        for error in reverse_outputs.keys():
            err_list_file.write(error)
            err_list_file.write('\n')
            err_list_file.write('\n')

    index = 0
    for error, file_list in reverse_outputs.items():
        if not "SUMMARY" in error:
            continue
        sorted_out_dir = os.path.join(sorted_dir, str(index))
        os.makedirs(sorted_out_dir, exist_ok=True)

        err_log = os.path.join(sorted_out_dir, 'error.log')
        with open(err_log, 'w') as log_file:
            log_file.write(error)

        out_file_name = os.path.join(reverse_output_dir, f'{index}.summary')
        with open(out_file_name, 'w') as output_file:
            for file_desc in file_list:
                file_name, mode, executable, raw_path = file_desc[:]
                output_file.write(f'{file_name}, {mode}, {executable}\n')
            output_file.write(f'\n{error}\n')
        
        shutil.copy(raw_path, sorted_out_dir)

        index += 1


if __name__ == "__main__":
    main()
